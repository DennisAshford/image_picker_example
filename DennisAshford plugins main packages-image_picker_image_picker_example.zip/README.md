# image_picker_example

Demonstrates how to use the image_picker plugin.
